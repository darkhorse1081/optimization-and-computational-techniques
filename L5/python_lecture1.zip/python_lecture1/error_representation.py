import numpy as np

if __name__ == '__main__':
    number = np.float32(0.1)
    print("  number = {:27.27f}".format(number))