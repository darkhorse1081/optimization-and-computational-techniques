# ENGSCI233 Lab: Iteration

# PURPOSE:
# To INVESTIGATE the fisheries management scenario in Task 2

# imports
from functions_itlab import *
from matplotlib import pyplot as plt

# your code here
