# TASK 2: Optimising

# imports
from functions_perflab import *

#TODO - your code here
if __name__ == "__main__":
    pass